//
//  ViewController.swift
//  Byte
//
//  Created by Salmah  on 22/02/1442 AH.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate{
    
    
    var result : UInt = 0

    
    @IBOutlet weak var MyLable: UILabel!
    
    @IBOutlet weak var MyTextArea: UITextField!
    
    @IBOutlet weak var switcher: UISwitch!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        MyTextArea.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        
        func textFieldDidChange(_ textField: UITextField) {

           if(MyLable.text == MyTextArea.text)
          {
              MyLable.backgroundColor = UIColor.red
            MyLable.backgroundColor = UIColor.white

          } else{
            MyLable.backgroundColor = UIColor.white

            }
    
        }

    }
    
    
    @IBAction func switchDidChange(_ sender : UISwitch){
       // var zeroOrOne : Int
       
        
        if sender.isOn{
            switch sender.tag{
            case 0 :
                result = result | 1
             case 1 :
                result = result | 2

            case 2 :
                result = result | 4

            case 3 :
                result = result | 8

            case 4 :
                result = result | 16

            case 5 :
                result = result | 32
            case 6 :
                result = result | 64
            case 7 :
                result = result | 128
            default: break
                
            }
            
         

        }
        else{
            switch sender.tag{
            case 0 :
                result = result & (~1)
            case 1 :
                result = result & (~2)
            case 2 :
                result = result & (~4)
            case 3 :
                result = result & (~8)
            case 4 :
                result = result & (~16)
            case 5 :
                result = result & (~32)
            case 6 :
                result = result & (~64)
            case 7 :
                result = result & (~128)
            default: break
                
            }
            

                            
            }
        MyLable.text = String(Int(result))
        MyLable.backgroundColor = UIColor.white


        }
        
    @objc func textFieldDidChange(_ textField: UITextField) {
        if(MyLable.text == textField.text)
     {
            MyLable.backgroundColor = UIColor.green
        }
        else{
        MyLable.backgroundColor = UIColor.white

        }
    }
    
        
    }


